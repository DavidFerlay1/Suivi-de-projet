<?php

namespace Hakam\MultiTenancyBundle\Exception;

class MultiTenancyException extends \Exception
{
}
