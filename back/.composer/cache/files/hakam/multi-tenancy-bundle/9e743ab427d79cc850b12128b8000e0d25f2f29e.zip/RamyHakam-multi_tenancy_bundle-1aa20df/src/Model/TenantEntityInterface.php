<?php

namespace Hakam\MultiTenancyBundle\Model;

/**
 * Implement this class on any Tenant entity items to identify the entity for selecting entity managers.
 */
interface TenantEntityInterface
{
}
