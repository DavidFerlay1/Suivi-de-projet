<?php

namespace Hakam\MultiTenancyBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

/**
 * @author Ramy Hakam <pencilsoft1@gmail.com>
 */
class HakamMultiTenancyBundle extends Bundle
{
}
